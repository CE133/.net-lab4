﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp_SR
{
    public partial class reg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void print(object sender, CommandEventArgs e)
        {
            pname.Text = Name.Text;
            pgender.Text = Gender.Text;
            pmobile.Text = mobile.Text;
            pbio.Text = Bio.Text;
            pcountry.Text = Country.Text;
            phobbies.Text = hobbies.Text;
            ppass.Text = Password.Text;
        }
    }
}